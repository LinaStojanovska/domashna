package com.example.project1.repo;

import com.example.project1.model.IssuerDetailsModel;
import com.example.project1.model.IssuerModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Optional;

@Repository
public interface IssuerDetailsRepository extends JpaRepository<IssuerDetailsModel, Long> {
    Optional<IssuerDetailsModel> findByDateAndCompany(LocalDate date, IssuerModel issuerModel);
}
