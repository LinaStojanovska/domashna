package com.example.project1.repo;

import com.example.project1.model.IssuerModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface IssuerRepository extends JpaRepository<IssuerModel, Long> {
    Optional<IssuerModel> findByCompanyCode(String companyCode);
}
